﻿$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
    Add-Type -AssemblyName System.Speech
    $info = [System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers() | Where-Object {$_.Culture.Name -eq 'zh-CN'} | Select-Object -First 1
    if (-not $info) { throw '未安装 Windows 中文语音识别组件，请使用文字指令' }
    $engine = New-Object System.Speech.Recognition.SpeechRecognitionEngine($info)
    $choices = New-Object System.Speech.Recognition.Choices
    $choices.Add([string[]]@('小萤开始陪伴','小萤暂停陪伴','小萤开始专注','小萤结束专注','小萤眼部米字操','小萤颈部十字操','小萤检查眼周','小萤检查舌苔','小萤检查皮肤','小萤观察情绪','小萤石头剪刀布'))
    $builder = New-Object System.Speech.Recognition.GrammarBuilder
    $builder.Culture = $info.Culture
    $builder.Append($choices)
    $engine.LoadGrammar((New-Object System.Speech.Recognition.Grammar($builder)))
    $engine.SetInputToDefaultAudioDevice()
    [Console]::WriteLine('{"ready":true}')
    while ($true) {
        $result = $engine.Recognize([TimeSpan]::FromSeconds(3))
        if ($result -and $result.Confidence -ge 0.55) {
            [Console]::WriteLine((@{text=$result.Text;confidence=$result.Confidence} | ConvertTo-Json -Compress))
        }
    }
} catch {
    [Console]::WriteLine((@{error=$_.Exception.Message} | ConvertTo-Json -Compress))
} finally {
    if ($engine) { $engine.Dispose() }
}
