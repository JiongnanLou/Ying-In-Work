from __future__ import annotations
import json
import math
import os
import subprocess
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import cv2
from backend.ai.vision import VisionAnalyzer, AnalysisError
from backend.database import Database, utc_now
from camera_service import CameraService, NativeCamera
from eyelei.tracker import EyeFatigueTracker
from jiuzuo.tracker import SedentaryTracker
from gesture_game import GestureGame
from portrait_tracking import PortraitTracker
import mizicao

DEFAULTS = {"sit_minutes": 60, "eye_minutes": 50, "focus_minutes": 25,
            "dnd": False, "cloud_consent": False, "sound": False,
            "auto_emotion": True, "auto_start": True, "hardware_exercise": True,
            "floating_window": True, "auto_tracking": True, "resolution": "1280x720"}


class ProductService:
    def __init__(self, root, data_dir):
        self.root, self.data_dir = Path(root), Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.settings_path = self.data_dir / "settings.json"
        self.settings = dict(DEFAULTS)
        saved = {}
        try:
            saved = json.loads(self.settings_path.read_text("utf-8-sig"))
            self.settings.update({k: v for k, v in saved.items() if k in DEFAULTS})
        except (OSError, ValueError):
            pass
        # Apply the requested new defaults once when upgrading from 1.0.
        if saved.get('_ui_revision') != 2:
            for key in ('auto_emotion', 'auto_start', 'hardware_exercise', 'floating_window'):
                self.settings[key] = True
        self.db = Database(self.data_dir / "records.db")
        self.db.end_work()  # recover interrupted previous session
        with self.db.connect() as db:
            db.execute("CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY, kind TEXT, label TEXT, created_at TEXT)")
        self.ai = VisionAnalyzer.from_environment(self.data_dir / "ai_config.json")
        self.camera, self.native = CameraService(), NativeCamera(self.root)
        self.lock = threading.RLock()
        self.operations = threading.Lock()
        self.stop_event = threading.Event()
        self.exercise_cancel = threading.Event()
        self.exercise_thread = None
        self.exercise = {"active": False}
        self.job = {"state": "idle"}
        self.job_cancel = threading.Event()
        self.notifications = []
        self.serial = 0
        self.presence = "unknown"
        self.last_face = 0
        self.last_observation = 0
        self.camera_generation = 0
        self.latest_emotion = None
        self.last_emotion = time.monotonic()
        self.emotion_busy = False
        self.emotion_epoch = 0
        self.emotion_status = {"state": "waiting", "updated_at": None, "error": None, "interval": 10}
        self.game = GestureGame(self)
        self.focus = {"active": False, "remaining": 0}
        self.voice_proc = None
        self.voice = {"active": False, "status": "未开启", "last_text": "", "seq": 0}
        self.sit = SedentaryTracker(self.settings["sit_minutes"] * 60)
        self.eye = EyeFatigueTracker(60, self.settings["eye_minutes"])
        self.detector = cv2.CascadeClassifier(str(self.root / "assets/haarcascade_frontalface_default.xml"))
        if self.detector.empty():
            raise RuntimeError("本地在场检测模型缺失")
        self.tracking = PortraitTracker(self)
        self.thread = threading.Thread(target=self._tick, daemon=True)
        self.thread.start()
        self.update_settings({})

    def event(self, kind, label):
        with self.db.connect() as db:
            db.execute("INSERT INTO events(kind,label,created_at) VALUES(?,?,?)", (kind, label, utc_now()))

    def notify(self, kind, label):
        self.event(kind, label)
        with self.lock:
            self.serial += 1
            self.notifications.append({"id": self.serial, "kind": kind, "label": label})
            self.notifications = self.notifications[-20:]

    def update_settings(self, data):
        with self.lock:
            candidate = dict(self.settings)
            for k in DEFAULTS:
                if k not in data:
                    continue
                if k.endswith("minutes"):
                    value = int(data[k])
                    if not 1 <= value <= 180:
                        raise ValueError("提醒及专注时长须为 1 到 180 分钟")
                elif k == "resolution":
                    value = data[k]
                    if value not in ("1280x720", "1920x1080", "3840x2160"):
                        raise ValueError("不支持的采集分辨率")
                else:
                    if not isinstance(data[k], bool):
                        raise ValueError("设置值须为开关状态")
                    value = data[k]
                candidate[k] = value
            old = self.settings
            self.settings = candidate
            if old["sit_minutes"] != candidate["sit_minutes"]:
                self.sit = SedentaryTracker(candidate["sit_minutes"] * 60)
            if old["eye_minutes"] != candidate["eye_minutes"]:
                self.eye = EyeFatigueTracker(60, candidate["eye_minutes"])
            if not candidate["cloud_consent"]:
                self.job_cancel.set()
            if not candidate["cloud_consent"] or not candidate["auto_emotion"]:
                self.emotion_epoch += 1
                self.emotion_status.update(state="paused", error=None)
            tmp = self.settings_path.with_suffix(".tmp")
            tmp.write_text(json.dumps({**candidate, '_ui_revision': 2}, ensure_ascii=False), "utf-8")
            os.replace(tmp, self.settings_path)
        return candidate

    def start_camera(self):
        if not self.acquire_operation():
            raise ValueError("相机正在切换，请稍后重试")
        try:
            width, height = map(int, self.settings["resolution"].split("x"))
            status = self.camera.start(width, height)
            self.camera_generation = status['generation']
            self.tracking.resume()
            self.last_emotion = time.monotonic()
            self.event("companion", "开始本地陪伴")
            return status
        finally:
            self.operations.release()

    def acquire_operation(self):
        # A short in-flight tracking step may finish before a foreground activity.
        if (self.exercise.get('active') or self.job.get('state') in ('capturing','analyzing')
                or self.game.status().get('state') in ('loading','countdown','recognizing')):
            return False
        acquired = self.operations.acquire(timeout=8)
        if acquired:
            try: self.tracking.suspend()
            except Exception:
                self.operations.release()
                raise
        return acquired

    def center_camera(self):
        if not self.camera.status()['capabilities']['gimbal']:
            raise ValueError('当前摄像头不支持云台回正；需要已开启的 Link 2')
        if not self.acquire_operation(): raise ValueError('请先结束当前活动')
        try:
            if not self.camera.status()['capabilities']['gimbal']:
                raise ValueError('Link 2 已断开，云台操作已取消')
            result = self.native.run('gimbal', 0, 0)
            self.tracking.invalidate()
            if not result.get('ok') or result.get('reached') is False:
                raise ValueError('相机未确认回正成功')
            return result
        finally:
            self.operations.release()

    def stop_camera(self):
        self.tracking.pause()
        with self.lock:
            self.emotion_epoch += 1
            self.emotion_status.update(state="paused", error=None)
        self.job_cancel.set()
        self.exercise_cancel.set()
        self.game.stop()
        self.camera.stop()
        self.tracking.invalidate()
        if self.exercise_thread and self.exercise_thread.is_alive():
            self.exercise_thread.join(timeout=18)
        with self.lock:
            self.sit.reset()
            self.eye.reset()
            self.presence = "unknown"
            self.last_face = 0
        return self.camera.status()

    def focus_start(self, minutes=None):
        minutes = int(minutes or self.settings["focus_minutes"])
        if not 1 <= minutes <= 180:
            raise ValueError("专注时长须为 1 到 180 分钟")
        with self.lock:
            if self.focus["active"]:
                return self.focus
            self.db.start_work()
            self.focus = {"active": True, "deadline": time.monotonic() + minutes * 60,
                          "minutes": minutes, "remaining": minutes * 60}
        return self.focus

    def focus_stop(self, completed=False):
        with self.lock:
            if self.focus["active"]:
                self.db.end_work()
                self.focus = {"active": False, "remaining": 0}
                self.notify("focus", "完成一轮专注" if completed else "结束本轮专注")
        return self.focus

    def reset_reminder(self, kind):
        with self.lock:
            if kind == "sit": self.sit.reset()
            elif kind == "eye": self.eye.reset()
            else: raise ValueError("未知提醒")

    def _tick(self):
        while not self.stop_event.wait(.5):
            now = time.monotonic()
            try:
                with self.lock:
                    if self.focus["active"]:
                        self.focus["remaining"] = max(0, math.ceil(self.focus["deadline"] - now))
                        if not self.focus["remaining"]:
                            self.focus_stop(completed=True)
                if self.camera.generation != self.camera_generation:
                    self.camera_generation = self.camera.generation
                    self.job_cancel.set()
                    self.exercise_cancel.set()
                    self.game.stop()
                    self.emotion_epoch += 1
                    self.last_face = 0
                    self.latest_emotion = None
                if self.camera.running and not self.exercise.get("active"):
                    if now - self.last_observation >= 1:
                        frame = self.camera.snapshot()
                        h,w=frame.shape[:2]
                        gray=cv2.cvtColor(cv2.resize(frame,(320,round(320*h/w))),cv2.COLOR_BGR2GRAY)
                        faces=self.detector.detectMultiScale(gray,1.1,5,minSize=(30,30))
                        if len(faces): self.last_face=now
                        present = now-self.last_face <= 3
                        self.presence="present" if present else "away"
                        self.last_observation=now
                        with self.lock:
                            if self.sit.update(present,now): self.notify("sit","坐了有一会儿了，起来活动一下吧")
                            if self.eye.update(present,now): self.notify("eye","让眼睛休息一下，看看远处")
                    self.schedule_emotion(now)
                elif not self.camera.running:
                    self.job_cancel.set()
                    self.exercise_cancel.set()
                    if self.game.status().get('state') in ('countdown','recognizing'):
                        self.game.stop()
                    self.presence="unknown"
                    with self.lock:
                        self.sit.reset(); self.eye.reset()
            except Exception:
                # Camera errors are visible through camera.status; never fabricate samples.
                self.presence="unknown"

    def schedule_emotion(self, now):
        """Ten-second sampling; one request at a time, no queued stale frames."""
        with self.lock:
            if (not self.camera.running or not self.settings['auto_emotion']
                    or not self.settings['cloud_consent'] or not self.ai.configured
                    or self.emotion_busy or self.operations.locked()
                    or now - self.last_emotion < 10):
                return False
            self.last_emotion = now
            self.emotion_busy = True
            epoch = self.emotion_epoch
            self.emotion_status.update(state='analyzing', error=None)
            threading.Thread(target=self._emotion_sample, args=(epoch,), daemon=True).start()
            return True

    def _emotion_sample(self, epoch):
        try:
            with self.lock:
                if epoch != self.emotion_epoch or self.stop_event.is_set():
                    return
                frame = self.camera.data_url(max_width=640)
                analyzer = self.ai
            result = analyzer.analyze('emotion', [frame])
            with self.lock:
                if epoch != self.emotion_epoch or self.stop_event.is_set():
                    return
                self.latest_emotion = result
                self.emotion_status.update(state='ready', updated_at=utc_now(), error=None)
                self.db.add_analysis('emotion', result, analyzer.provider)
        except Exception as exc:
            with self.lock:
                if epoch == self.emotion_epoch:
                    self.emotion_status.update(state='error', error=str(exc))
        finally:
            with self.lock:
                self.emotion_busy = False

    def analyze_start(self, kind):
        if kind not in ("dark_circle","tongue","acne","emotion"):
            raise ValueError("该功能尚未接入；卡路里仅预留入口")
        if not self.settings["cloud_consent"]:
            raise ValueError("请先在设置中允许将采集图像发送至配置的 Qwen 服务")
        if not self.ai.configured:
            raise ValueError("请先在设置中填写 Qwen API 地址、模型 ID 和密钥")
        self.camera.snapshot()
        if not self.acquire_operation():
            raise ValueError("当前采集或活动尚未结束")
        self.job_cancel.clear()
        self.job={"state":"capturing","kind":kind,"countdown":6}
        threading.Thread(target=self._analyze,args=(kind,),daemon=True).start()
        return dict(self.job)

    def _analyze(self, kind):
        try:
            images=[]
            for remaining in range(6,0,-1):
                self.job={"state":"capturing","kind":kind,"countdown":remaining}
                if self.job_cancel.wait(1): raise ValueError("本次采集已取消")
                if remaining in (5,3,1): images.append(self.camera.data_url())
            if self.job_cancel.is_set() or not self.settings["cloud_consent"]:
                raise ValueError("本次分析已取消")
            self.job={"state":"analyzing","kind":kind}
            result=self.ai.analyze(kind,images)
            if self.job_cancel.is_set(): raise ValueError("本次结果已丢弃；已发送的请求无法撤回")
            self.db.add_analysis(kind,result,self.ai.provider)
            self.job={"state":"done","kind":kind,"result":result}
            if kind=="emotion":
                self.latest_emotion=result
                self.emotion_status.update(state='ready', updated_at=utc_now(), error=None)
                if result.get("confidence",0)>=.6 and result.get("mood") in ("tired","low"):
                    self.notify("care","要不要和小萤一起休息片刻？")
        except Exception as exc:
            self.job={"state":"error","kind":kind,"error":str(exc)}
        finally:
            self.operations.release()

    def start_exercise(self, kind, hardware=None):
        if kind not in ("eye","neck","breath"): raise ValueError("未知活动")
        if hardware is None:
            hardware = self.settings['hardware_exercise'] and kind != 'breath'
            if self.camera.running and not self.camera.link2: hardware = False
        if not self.acquire_operation(): raise ValueError("请先结束当前采集或活动")
        if hardware and not self.camera.running:
            self.operations.release()
            raise ValueError("请先开始陪伴，再使用云台联动")
        if hardware and not self.camera.status()['capabilities']['gimbal']:
            self.operations.release()
            raise ValueError('当前摄像头没有云台；请使用屏幕引导活动')
        self.exercise_cancel.clear()
        self.exercise={"active":True,"kind":kind,"label":"准备开始","x":0,"y":0,"step":0,"total":1,"hardware":hardware}
        self.exercise_thread=threading.Thread(target=self._exercise,args=(kind,hardware),daemon=True)
        self.exercise_thread.start()
        return dict(self.exercise)

    def _exercise(self,kind,hardware):
        completed=False
        error=None
        try:
            if hardware:
                result=self.native.run("features","off")
                if not result.get("ok"): raise ValueError("无法暂停相机跟踪，云台活动已取消")
            if kind=="eye":
                # Preserve the supplied sequence; scale SDK travel for a desktop routine.
                steps=[(s.point.pan/60,s.point.tilt/60,max(.45,s.hold_seconds),"目光跟随光点，头部保持自然")
                       for s in mizicao.eye_mizicao_sequence()]
            elif kind=="neck":
                steps=[(0,0,3,"坐稳，放松肩颈")]
                for x,y,label in [(0,1,"轻轻抬头"),(0,-1,"轻轻低头"),(-1,0,"轻轻向左"),(1,0,"轻轻向右")]:
                    steps.extend([(x,y,3,label),(0,0,2,"回到中间")])
            else:
                steps=[(0,0,4,"缓缓吸气"),(0,0,6,"慢慢呼气")]*6
            for i,(x,y,hold,label) in enumerate(steps):
                if self.exercise_cancel.is_set(): break
                self.exercise={"active":True,"kind":kind,"label":label,"x":x,"y":y,"step":i+1,"total":len(steps),"hardware":hardware}
                if hardware:
                    if not self.camera.status()['capabilities']['gimbal']:
                        raise ValueError('Link 2 已断开，云台联动已停止')
                    # Uploaded Link 2 routine maps physical vertical to SDK pan.
                    result=self.native.run("gimbal",round(y*20),round(-x*20))
                    if not result.get("ok") or result.get("reached") is False:
                        raise ValueError("云台未到达目标，已停止联动")
                if self.exercise_cancel.wait(hold): break
            completed=not self.exercise_cancel.is_set()
            if completed:
                self.event("exercise",{"eye":"完成眼部米字操","neck":"完成颈部十字操","breath":"完成呼吸放松"}[kind])
                self.eye.reset()
        except Exception as exc:
            error=str(exc)
        finally:
            if hardware and self.camera.status()['capabilities']['gimbal']:
                restored=self.native.run("gimbal",0,0)
                if not restored.get("ok"): error=(error or "")+" 云台回正未确认"
            self.exercise={"active":False,"kind":kind,"completed":completed,"error":error}
            if hardware: self.tracking.invalidate()
            self.operations.release()

    def start_voice(self):
        if self.voice_proc and self.voice_proc.poll() is None: return self.voice
        self.voice={"active":False,"status":"正在初始化中文语音","last_text":"","seq":self.voice["seq"]}
        self.voice_proc=subprocess.Popen(["powershell.exe","-NoProfile","-ExecutionPolicy","Bypass","-File",str(self.root/"voice.ps1")],
                                         stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,encoding="utf-8",errors="replace",creationflags=subprocess.CREATE_NO_WINDOW)
        threading.Thread(target=self._voice_read,args=(self.voice_proc,),daemon=True).start()
        return dict(self.voice)

    def _voice_read(self,proc):
        try:
            for line in proc.stdout:
                if self.voice_proc is not proc: break
                try: data=json.loads(line)
                except ValueError: continue
                if data.get("ready"): self.voice.update(active=True,status="本地聆听中 · 说“小萤…”")
                if data.get("error"): self.voice.update(active=False,status=data["error"])
                if data.get("text"):
                    self.voice.update(last_text=data["text"],seq=self.voice["seq"]+1)
        finally:
            if self.voice_proc is proc:
                self.voice["active"]=False

    def stop_voice(self):
        proc,self.voice_proc=self.voice_proc,None
        if proc and proc.poll() is None:
            proc.terminate()
            try: proc.wait(timeout=3)
            except subprocess.TimeoutExpired: proc.kill()
        self.voice.update(active=False,status="未开启")
        return dict(self.voice)

    def history(self):
        data=self.db.dashboard()
        with self.db.connect() as db:
            data["events"]=[dict(r) for r in db.execute("SELECT * FROM events ORDER BY id DESC LIMIT 100")]
            data["trends"]=[dict(r) for r in db.execute("SELECT kind,score,confidence,created_at FROM analyses ORDER BY id DESC LIMIT 200")]
        return data

    def clear_data(self):
        if self.operations.locked():
            raise ValueError("请先等待当前采集或活动结束再清除记录")
        with self.lock:
            self.focus_stop()
            self.db.clear_all()
            with self.db.connect() as db: db.execute("DELETE FROM events")
            self.notifications=[]
            self.latest_emotion=None
            self.emotion_epoch += 1
            self.emotion_status.update(state='waiting', updated_at=None, error=None)
            self.job={"state":"idle"}

    def status(self):
        with self.lock:
            return {"version":"1.3.1","camera":self.camera.status(),"settings":dict(self.settings),
                    "tracking":self.tracking.status(),
                    "ai":self.ai.public_config(),"presence":self.presence,"focus":dict(self.focus),
                    "sit":{"seconds":round(self.sit.accumulated_seconds),"progress":self.sit.progress_ratio},
                    "eye":{"progress":self.eye.progress_ratio},"job":dict(self.job),"exercise":dict(self.exercise),
                    "notifications":list(self.notifications),"voice":dict(self.voice),"emotion":self.latest_emotion,
                    "emotion_status":{**self.emotion_status, 'busy':self.emotion_busy,
                                      'next_in':max(0, math.ceil(10-(time.monotonic()-self.last_emotion)))},
                    "game":self.game.status()}

    def close(self):
        self.stop_event.set()
        self.tracking.close()
        self.stop_voice()
        self.stop_camera()
        self.game.close()
        self.focus_stop()
