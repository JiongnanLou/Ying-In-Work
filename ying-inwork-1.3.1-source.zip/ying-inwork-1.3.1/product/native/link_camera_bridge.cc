#include <uvc_camera.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

using namespace uvc;

namespace {
constexpr long kExtPanTiltUnitsPerDegree = 3600;

std::string JsonEscape(const std::string& value) {
    std::ostringstream out;
    for (char c : value) {
        if (c == '"' || c == '\\') out << '\\' << c;
        else if (c == '\n') out << "\\n";
        else out << c;
    }
    return out.str();
}

void PrintError(const std::string& message) {
    std::cout << "{\"ok\":false,\"error\":\"" << JsonEscape(message) << "\"}" << std::endl;
}

bool MoveAndWait(UVCCameraExtendController& camera, int32_t pan, int32_t tilt) {
    if (!camera.SetPanTiltAbsolute(pan, tilt)) return false;
    const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(3);
    while (std::chrono::steady_clock::now() < deadline) {
        int32_t actual_pan = 0;
        int32_t actual_tilt = 0;
        if (camera.GetPanTiltAbsoluteValue(actual_pan, actual_tilt) &&
            std::abs(actual_pan - pan) <= 2 * kExtPanTiltUnitsPerDegree &&
            std::abs(actual_tilt - tilt) <= 2 * kExtPanTiltUnitsPerDegree) {
            return true;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(40));
    }
    return false;
}

bool SetResidentFeatures(UVCCameraExtendController& camera) {
    VideoModeAuxiliaryData data{};
    bool ok = camera.SetPrivacyMode(false);
    ok = camera.SetDefaultTrackMode(0) && ok;
    ok = camera.SetCompositionStyle(CompositionStyle::HalfBody) && ok;
    ok = camera.SetTrackSpeed(TrackSpeed::Normal) && ok;
    ok = camera.SetCompositionBias(0, 0) && ok;
    ok = camera.SetVideoMode(VideoMode::AutoComposition, data) && ok;
    ok = camera.GestureBinding(Gesture::Gesture_Palm, GestureFunction::Track) && ok;
    ok = camera.GestureBinding(Gesture::Gesture_L, GestureFunction::Zoom) && ok;
    ok = camera.GestureBinding(Gesture::Gesture_V, GestureFunction::AutoComposition) && ok;
    ok = camera.EnableGestureWork(Gesture::Gesture_Palm, true) && ok;
    ok = camera.EnableGestureWork(Gesture::Gesture_L, true) && ok;
    ok = camera.EnableGestureWork(Gesture::Gesture_V, true) && ok;
    ok = camera.EnableAllGesture(true) && ok;
    return ok;
}
}  // namespace

int main(int argc, char** argv) {
    std::vector<UVCCameraInfo> cameras;
    GetUVCCameraList(cameras);
    if (cameras.empty()) {
        PrintError("未发现 Insta360 Link 相机");
        return 2;
    }

    auto selected = cameras.end();
    for (auto it = cameras.begin(); it != cameras.end(); ++it) {
        // Link 2 host/flow USB product IDs from uvc_common.h.
        if (it->product_id == kPUC2ProductHostId_ || it->product_id == kPUC2ProductFlowId_) {
            selected = it;
            break;
        }
    }
    if (selected == cameras.end()) {
        PrintError("检测到相机，但不是 Insta360 Link 2");
        return 2;
    }
    const auto& info = *selected;
    UVCCameraController camera(info);
    UVCCameraExtendController ext(info);
    const std::string command = argc > 1 ? argv[1] : "status";

    if (command == "status") {
        std::cout << "{\"ok\":true,\"device\":\"" << JsonEscape(info.friendly_name)
                  << "\",\"video_device_index\":" << info.video_device_index
                  << ",\"product_id\":" << info.product_id << "}" << std::endl;
        return 0;
    }

    if (command == "privacy") {
        if (argc < 3) {
            PrintError("privacy 需要 on 或 off");
            return 1;
        }
        const bool enabled = std::string(argv[2]) == "on";
        const bool ok = ext.SetPrivacyMode(enabled);
        std::cout << "{\"ok\":" << (ok ? "true" : "false")
                  << ",\"privacy\":" << (enabled ? "true" : "false") << "}" << std::endl;
        return ok ? 0 : 3;
    }

    if (command == "keepalive") {
        const bool awake = ext.SetPrivacyMode(false);
        DeviceStatus device_status{};
        const bool responsive = ext.GetDeviceStatus(device_status);
        std::cout << "{\"ok\":" << (awake && responsive ? "true" : "false")
                  << ",\"awake\":" << (awake ? "true" : "false")
                  << ",\"responsive\":" << (responsive ? "true" : "false") << "}" << std::endl;
        return awake && responsive ? 0 : 3;
    }

    if (command == "gimbal") {
        if (argc < 4) {
            PrintError("gimbal 需要 pan 和 tilt 角度");
            return 1;
        }
        const int pan = std::stoi(argv[2]);
        const int tilt = std::stoi(argv[3]);
        const int32_t target_pan = pan * kExtPanTiltUnitsPerDegree;
        const int32_t target_tilt = tilt * kExtPanTiltUnitsPerDegree;
        // A downward 90-degree position activates Link 2 Privacy Mode. Always
        // request wake-up before moving so a recovery/centering command can
        // still bring the camera back if privacy was entered manually.
        const bool awake = ext.SetPrivacyMode(false);
        const bool ok = awake && ext.SetPanTiltAbsolute(target_pan, target_tilt);
        bool reached = false;
        int32_t actual_pan = 0;
        int32_t actual_tilt = 0;
        if (ok) {
            const auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(5);
            while (std::chrono::steady_clock::now() < deadline) {
                if (ext.GetPanTiltAbsoluteValue(actual_pan, actual_tilt)) {
                    const auto pan_error = std::abs(actual_pan - target_pan);
                    const auto tilt_error = std::abs(actual_tilt - target_tilt);
                    if (pan_error <= 2 * kExtPanTiltUnitsPerDegree &&
                        tilt_error <= 2 * kExtPanTiltUnitsPerDegree) {
                        reached = true;
                        break;
                    }
                }
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
            }
        }
        std::cout << "{\"ok\":" << (ok ? "true" : "false")
                  << ",\"awake\":" << (awake ? "true" : "false")
                  << ",\"reached\":" << (reached ? "true" : "false")
                  << ",\"pan\":" << pan << ",\"tilt\":" << tilt
                  << ",\"actual_pan\":" << actual_pan / kExtPanTiltUnitsPerDegree
                  << ",\"actual_tilt\":" << actual_tilt / kExtPanTiltUnitsPerDegree
                  << "}" << std::endl;
        return ok ? 0 : 3;
    }

    if (command == "react") {
        if (argc < 3) {
            PrintError("react 需要 happy、low 或 tired");
            return 1;
        }
        const std::string mood = argv[2];
        if (mood != "happy" && mood != "low" && mood != "tired") {
            PrintError("不支持的互动状态");
            return 1;
        }

        bool motion_ok = true;
        if (mood != "tired") {
            VideoModeAuxiliaryData normal_data{};
            motion_ok = ext.SetVideoMode(VideoMode::Normal, normal_data);
            int32_t base_pan = 0;
            int32_t base_tilt = 0;
            motion_ok = ext.GetPanTiltAbsoluteValue(base_pan, base_tilt) && motion_ok;
            const int32_t pan_min = -145 * kExtPanTiltUnitsPerDegree;
            const int32_t pan_max = 145 * kExtPanTiltUnitsPerDegree;
            const int32_t tilt_min = -45 * kExtPanTiltUnitsPerDegree;
            const int32_t tilt_max = 90 * kExtPanTiltUnitsPerDegree;
            if (motion_ok && mood == "happy") {
                const int32_t down = std::clamp<int32_t>(base_pan - 12 * kExtPanTiltUnitsPerDegree, pan_min, pan_max);
                const int32_t up = std::clamp<int32_t>(base_pan + 8 * kExtPanTiltUnitsPerDegree, pan_min, pan_max);
                motion_ok = MoveAndWait(ext, down, base_tilt) && motion_ok;
                motion_ok = MoveAndWait(ext, up, base_tilt) && motion_ok;
                motion_ok = MoveAndWait(ext, base_pan, base_tilt) && motion_ok;
            } else if (motion_ok) {
                const int32_t left = std::clamp<int32_t>(base_tilt + 14 * kExtPanTiltUnitsPerDegree, tilt_min, tilt_max);
                const int32_t right = std::clamp<int32_t>(base_tilt - 14 * kExtPanTiltUnitsPerDegree, tilt_min, tilt_max);
                motion_ok = MoveAndWait(ext, base_pan, left) && motion_ok;
                motion_ok = MoveAndWait(ext, base_pan, right) && motion_ok;
                motion_ok = MoveAndWait(ext, base_pan, base_tilt) && motion_ok;
            }
            motion_ok = SetResidentFeatures(ext) && motion_ok;
        }
        const bool ok = motion_ok;
        std::cout << "{\"ok\":" << (ok ? "true" : "false")
                  << ",\"mood\":\"" << mood << "\""
                  << ",\"light_supported\":false"
                  << ",\"motion\":\"" << (mood == "happy" ? "nod" : (mood == "low" ? "shake" : "none")) << "\""
                  << "}" << std::endl;
        return ok ? 0 : 3;
    }

    if (command == "features") {
        if (argc < 3) {
            PrintError("features 需要 on 或 off");
            return 1;
        }
        const bool enabled = std::string(argv[2]) == "on";
        bool tracking_ok = true;
        bool gestures_ok = true;
        VideoModeAuxiliaryData data{};
        if (enabled) {
            tracking_ok = SetResidentFeatures(ext);
            gestures_ok = tracking_ok;
        }
        else {
            gestures_ok = ext.EnableAllGesture(false);
            tracking_ok = ext.SetVideoMode(VideoMode::Normal, data);
        }
        const bool ok = tracking_ok && gestures_ok;
        std::cout << "{\"ok\":" << (ok ? "true" : "false")
                  << ",\"enabled\":" << (enabled ? "true" : "false")
                  << ",\"tracking\":" << (tracking_ok ? "true" : "false")
                  << ",\"gestures\":" << (gestures_ok ? "true" : "false")
                  << ",\"tracking_mode\":\"single-person\""
                  << ",\"composition\":\"half-body-centered\""
                  << ",\"gesture_palm\":\"tracking\""
                  << ",\"gesture_l\":\"zoom\""
                  << ",\"gesture_v\":\"auto-composition\"}" << std::endl;
        return ok ? 0 : 3;
    }

    if (command == "profile") {
        const std::string kind = argc > 2 ? argv[2] : "health";
        bool ok = true;
        ok = ext.SetPrivacyMode(false) && ok;
        ok = ext.EnableAutoExposure(true) && ok;
        ok = camera.SetWhitebalanceTemperatureMode(1) && ok;
        ok = ext.SetExposureCompensation(0.0f) && ok;
        ok = ext.SetFilter(FilterMode::Standard) && ok;
        ok = ext.EnableExtendFuncWork(ExtendFuction::HDR, false) && ok;
        ok = ext.EnableExtendFuncWork(ExtendFuction::Mirror, false) && ok;
        ok = camera.EnableAutoFocus(true) && ok;

        std::cout << "{\"ok\":" << (ok ? "true" : "false")
                  << ",\"profile\":\"" << JsonEscape(kind)
                  << "\",\"auto_exposure\":true,\"auto_white_balance\":true}" << std::endl;
        return ok ? 0 : 3;
    }

    PrintError("未知命令");
    return 1;
}
