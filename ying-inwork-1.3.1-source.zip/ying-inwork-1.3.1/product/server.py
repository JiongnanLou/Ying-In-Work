import io
import json
import secrets
from pathlib import Path
from flask import Flask, Response, request, send_from_directory, jsonify, abort
from werkzeug.exceptions import HTTPException


def create_app(service, token=None):
    app=Flask(__name__,static_folder=None)
    app.config['MAX_CONTENT_LENGTH']=1024*1024
    token=token or secrets.token_urlsafe(32)
    app.config['TOKEN']=token
    frontend=service.root/'frontend'

    @app.before_request
    def protect():
        if request.path.startswith('/api/'):
            supplied=request.headers.get('X-InWork-Token','')
            if request.path=='/api/frame': supplied=request.args.get('token','')
            if not secrets.compare_digest(supplied,token): abort(403)
            if request.headers.get('Origin') and request.headers['Origin'] != request.host_url.rstrip('/'):
                abort(403)

    @app.after_request
    def headers(response):
        response.headers['Cache-Control']='no-store'
        response.headers['X-Content-Type-Options']='nosniff'
        response.headers['X-Frame-Options']='DENY'
        response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'"
        return response

    @app.errorhandler(Exception)
    def error(exc):
        if isinstance(exc,HTTPException): return jsonify(error=exc.description),exc.code
        return jsonify(error=str(exc)),400

    @app.get('/')
    def index():
        return Response((frontend/'index.html').read_text('utf-8').replace('__SESSION_TOKEN__',token),mimetype='text/html')

    @app.get('/assets/<path:name>')
    def assets(name): return send_from_directory(frontend/'assets',name)

    @app.get('/<name>')
    def static_file(name):
        if name not in ('app.js','style.css','game.js'): abort(404)
        return send_from_directory(frontend,name)

    @app.get('/api/status')
    def status(): return jsonify(service.status())

    @app.get('/api/devices')
    def devices(): return jsonify(devices=service.camera.devices())

    @app.get('/api/history')
    def history(): return jsonify(service.history())

    @app.get('/api/frame')
    def frame():
        with service.camera.lock:
            data=service.camera.jpeg
        if not data: return Response(status=204)
        return Response(data,mimetype='image/jpeg')

    @app.get('/api/export')
    def export():
        data={'product':'萤 In Work','version':'1.3.1','records':service.history()}
        return Response(json.dumps(data,ensure_ascii=False,indent=2),mimetype='application/json')

    @app.post('/api/<path:action>')
    def action(action):
        data=request.get_json(silent=True) or {}
        if action=='camera/start': result=service.start_camera()
        elif action=='camera/stop': result=service.stop_camera()
        elif action=='settings': result=service.update_settings(data)
        elif action=='focus/start': result=service.focus_start(data.get('minutes'))
        elif action=='focus/stop': result=service.focus_stop()
        elif action=='reminder/reset': service.reset_reminder(data.get('kind'));result={'ok':True}
        elif action=='analyze': result=service.analyze_start(data.get('kind'))
        elif action=='analyze/cancel': service.job_cancel.set();result={'ok':True}
        elif action=='exercise/start': result=service.start_exercise(data.get('kind'),data.get('hardware'))
        elif action=='exercise/stop': service.exercise_cancel.set();result={'ok':True}
        elif action=='voice/start': result=service.start_voice()
        elif action=='voice/stop': result=service.stop_voice()
        elif action=='game/start': result=service.game.start()
        elif action=='game/stop': service.game.stop();result={'ok':True}
        elif action=='game/reset': result=service.game.reset()
        elif action=='camera/center':
            result=service.center_camera()
        elif action=='ai/config':
            key=str(data.get('api_key','')).strip() or service.ai.api_key or ''
            result=service.ai.configure(key,str(data.get('base_url','')),str(data.get('model','')))
        elif action=='ai/test': result=service.ai.test_connection()
        elif action=='ai/clear': service.ai.clear_config();result={'ok':True}
        elif action=='data/clear':
            if data.get('confirm') is not True: raise ValueError('请确认清除本地记录')
            service.clear_data();result={'ok':True}
        elif action=='game/completed':
            winner=data.get('winner')
            if winner not in ('user','cpu'): raise ValueError('无效对局结果')
            service.event('game','完成一场石头剪刀布');result={'ok':True}
        else: abort(404)
        return jsonify(result if result is not None else {'ok':True})
    return app
