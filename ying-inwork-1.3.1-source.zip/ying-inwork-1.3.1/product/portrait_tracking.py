"""Link 2 native portrait tracking; no application-controlled search motion."""
import threading
import time

from face_detector import FaceDetector


class PortraitTracker:
    def __init__(self, service):
        self.service = service
        self.stop_event = threading.Event()
        self.motion_lock = threading.RLock()
        self.paused = False
        self.native_mode = False
        self.generation = -1
        self.last_telemetry = 0
        self.retry_at = 0
        self.telemetry = {}
        self.off_center_since = None
        self.state = {'state':'paused','label':'陪伴开启后启用原生人像追踪','error':None}
        self.thread = threading.Thread(target=self._run, daemon=True, name='portrait-tracker')
        self.thread.start()

    def invalidate(self):
        self.generation = -1
        self.off_center_since = None

    def status(self):
        return dict(self.state)

    def report(self, state, label, error=None, **details):
        self.state = {'state':state,'label':label,'error':error, **details}

    def _mode(self, enabled):
        if self.native_mode == enabled: return
        result = self.service.native.run('tracking','on' if enabled else 'off')
        if not result.get('ok'):
            if enabled: self.native_mode = True  # Force an off command after partial setup.
            raise RuntimeError(result.get('error','Link 2 未确认追踪模式'))
        self.native_mode = enabled

    def suspend(self):
        """Caller holds the foreground operation lock; firmware must stop too."""
        with self.motion_lock:
            if self.native_mode: self._mode(False)
            self.off_center_since = None
            self.report('activity','当前活动期间暂停原生追踪')

    def pause(self):
        with self.motion_lock:
            self.paused = True
            try: self._mode(False)
            except RuntimeError as exc: self.report('error','停止追踪未获设备确认',str(exc))
            self.invalidate()

    def resume(self):
        with self.motion_lock:
            self.paused = False
            self.retry_at = 0

    def _run(self):
        try:
            detector = FaceDetector(self.service.root)
            while not self.stop_event.wait(.12):
                s = self.service
                camera = s.camera.status()
                if not camera['running'] or self.paused:
                    self.report('paused','陪伴暂停 · 自动追踪已停止')
                    continue
                if not camera['capabilities']['tracking']:
                    self.native_mode = False
                    self.invalidate()
                    self.report('unsupported','本机摄像头 · 无云台追踪')
                    continue
                if not s.settings['auto_tracking']:
                    try:
                        with self.motion_lock:
                            if self.native_mode: self._mode(False)
                        self.report('disabled','原生人像追踪已关闭')
                    except RuntimeError as exc:
                        self.report('error','停止追踪未获设备确认',str(exc))
                    continue
                if time.monotonic() < self.retry_at: continue
                if not s.operations.acquire(blocking=False):
                    self.report('activity','当前活动期间暂停原生追踪')
                    continue
                try:
                    with self.motion_lock:
                        if self.paused or self.stop_event.is_set(): continue
                        if not s.camera.running or not s.camera.link2: continue
                        now = time.monotonic()
                        new_stream = self.generation != camera['generation']
                        if new_stream or now-self.last_telemetry >= 1:
                            self.telemetry = s.native.run('telemetry')
                            self.last_telemetry = now
                            if not self.telemetry.get('ok') or not self.telemetry.get('stream_open'):
                                raise RuntimeError('Link 2 未确认视频流。请关闭其他相机应用，再重新开始陪伴。')
                            if self.telemetry.get('mode') == 0:
                                self.native_mode = False
                        if new_stream:
                            self.report('initializing','正在开启 Link 2 原生人像追踪')
                            self.native_mode = False
                            self._mode(True)
                            self.generation = camera['generation']
                        if self.generation != s.camera.generation: continue
                        # Firmware remains responsible for tracking, including reacquisition.
                        # Resume it after foreground activities even when no face is visible.
                        self._mode(True)
                        frame = s.camera.snapshot()
                        faces,width,height = detector.detect(frame)
                        found = bool(faces) or (self.native_mode and bool(self.telemetry.get('objects')))
                        if found:
                            centered = False
                            box = None
                            if faces:
                                x,y,w,h = max(faces,key=lambda f:f[2]*f[3])
                                box = [x/width,y/height,w/width,h/height]
                                centered = abs((x+w/2)/width-.5)<.12 and abs((y+h/2)/height-.5)<.16
                            if centered:
                                self.off_center_since = None
                            elif faces and self.off_center_since is None:
                                self.off_center_since = now
                            stalled = self.off_center_since is not None and now-self.off_center_since > 8
                            self.report('warning' if stalled else ('centered' if centered else 'following'),
                                        '云台尚未使人像居中，请检查设备' if stalled else
                                        ('人像已居中 · 原生追踪中' if centered else '已发现人像 · 正在调整构图'),
                                        native_tracking=True, face_box=box, face_count=len(faces))
                        else:
                            self.off_center_since = None
                            self.report('waiting','原生追踪已开启 · 等待人像进入画面',native_tracking=self.native_mode)
                except Exception as exc:
                    try: self._mode(False)
                    except RuntimeError: pass
                    self.report('error','追踪暂不可用，请检查设备',str(exc))
                    self.retry_at = time.monotonic()+5
                    self.invalidate()
                finally:
                    s.operations.release()
        except Exception as exc:
            self.report('error','本地人像检测不可用',str(exc))
        finally:
            with self.motion_lock:
                try: self._mode(False)
                except RuntimeError: pass

    def close(self):
        self.stop_event.set()
        self.thread.join(timeout=18)
