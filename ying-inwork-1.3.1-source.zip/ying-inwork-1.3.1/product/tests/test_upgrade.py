import json
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from service import ProductService
from gesture_game import StableHand, classify, outcome
from floating_companion import dock_position


class UpgradeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.svc=ProductService(ROOT,self.tmp.name)
        self.svc.stop_event.set()
        self.svc.thread.join(2)
        self.svc.stop_event.clear()

    def tearDown(self):
        self.svc.close()
        self.tmp.cleanup()

    def test_requested_defaults_and_saved_opt_out(self):
        for key in ('auto_start','auto_emotion','hardware_exercise','floating_window'):
            self.assertTrue(self.svc.settings[key])
        self.svc.update_settings({'auto_start':False,'floating_window':False})
        other=ProductService(ROOT,self.tmp.name)
        try:
            self.assertFalse(other.settings['auto_start'])
            self.assertFalse(other.settings['floating_window'])
        finally:other.close();other.thread.join(2)

    def test_ten_second_sampling_no_overlap_and_no_result_after_pause(self):
        entered,release=threading.Event(),threading.Event()
        result={'summary':'test','mood':'calm','score':50,'confidence':.9,'activity':'unknown','metrics':{},'suggestions':[]}
        def analyze(*_):
            entered.set();release.wait(3);return result
        self.svc.camera.running=True
        self.svc.settings['cloud_consent']=True
        self.svc.ai.api_key='test-key'
        self.svc.ai.base_url='https://example.com/v1'
        self.svc.ai.model='test'
        last=self.svc.last_emotion
        with patch.object(self.svc.camera,'data_url',return_value='test-frame'),patch.object(self.svc.ai,'analyze',side_effect=analyze) as cloud:
            self.assertFalse(self.svc.schedule_emotion(last+9.9))
            self.assertTrue(self.svc.schedule_emotion(last+10))
            self.assertTrue(entered.wait(1))
            self.assertFalse(self.svc.schedule_emotion(last+20))
            self.svc.stop_camera()
            release.set()
            deadline=time.monotonic()+2
            while self.svc.emotion_busy and time.monotonic()<deadline:time.sleep(.01)
            self.assertIsNone(self.svc.latest_emotion)
            self.assertEqual(cloud.call_count,1)
            self.assertEqual(self.svc.history()['recent'],[])

    def test_gesture_no_camera_no_cloud_and_auth(self):
        from server import create_app
        app=create_app(self.svc,'test')
        with patch.object(self.svc.ai,'analyze') as cloud:
            client=app.test_client()
            self.assertEqual(client.post('/api/game/start',json={}).status_code,403)
            self.assertEqual(client.post('/api/game/start',json={},headers={'X-InWork-Token':'test'}).status_code,400)
            self.assertFalse(cloud.called)
            self.assertEqual(self.svc.game.state['userWins'],0)

    def test_hardware_default_requires_active_camera(self):
        with self.assertRaises(ValueError):self.svc.start_exercise('neck')
        self.assertFalse(self.svc.operations.locked())


class GestureAndDockTests(unittest.TestCase):
    def test_fast_emotion_uses_compact_non_thinking_and_rejects_bad_numbers(self):
        from backend.ai.vision import VisionAnalyzer, AnalysisError
        analyzer=VisionAnalyzer(api_key='not-a-real-key',model='test')
        body={'choices':[{'message':{'content':json.dumps({'mood':'calm','confidence':.8,'summary':'表情平静'})}}]}
        with patch.object(analyzer,'_request_chat',return_value=body) as request:
            result=analyzer._qwen_emotion('test-image')
            payload=request.call_args.args[0]
            self.assertFalse(payload['enable_thinking'])
            self.assertLessEqual(payload['max_tokens'],200)
            self.assertEqual(result['mood'],'calm')
            self.assertIsNone(result['score'])
        body['choices'][0]['message']['content']='{"mood":"calm","confidence":NaN,"summary":"x"}'
        with patch.object(analyzer,'_request_chat',return_value=body):
            with self.assertRaises(AnalysisError):analyzer._qwen_emotion('test-image')

    def test_invalid_multiple_lowconfidence_hands_never_score(self):
        cat=lambda name,score:SimpleNamespace(category_name=name,score=score)
        res=lambda gs:SimpleNamespace(gestures=gs)
        self.assertEqual(classify(res([])),(None,0))
        self.assertEqual(classify(res([[cat('Victory',.4)]])),(None,0))
        self.assertEqual(classify(res([[cat('Thumb_Up',.99)]])),(None,0))
        self.assertEqual(classify(res([[cat('Victory',.99)],[cat('Open_Palm',.99)]])),(None,0))
        for name,expected in [('Closed_Fist','rock'),('Open_Palm','paper'),('Victory','scissors')]:
            self.assertEqual(classify(res([[cat(name,.9)]]))[0],expected)

    def test_hand_must_stabilize_and_new_gesture_resets(self):
        s=StableHand()
        self.assertFalse(s.update('rock',0))
        self.assertFalse(s.update('rock',.2))
        self.assertTrue(s.update('rock',.5))
        self.assertFalse(s.update('paper',.6))
        self.assertFalse(s.update(None,.9))
        self.assertFalse(s.update('paper',1.5))

    def test_all_matchups(self):
        for user in ('rock','paper','scissors'):
            self.assertEqual(outcome(user,user),'draw')
        for user,cpu in [('rock','scissors'),('paper','rock'),('scissors','paper')]:
            self.assertEqual(outcome(user,cpu),'win')
            self.assertEqual(outcome(cpu,user),'lose')
        with self.assertRaises(ValueError):outcome('unknown','paper')

    def test_docking_respects_negative_monitor_bounds_and_leaves_reveal_strip(self):
        bounds=(-1920,0,0,1080)
        self.assertEqual(dock_position(bounds,(100,130),(-1000,300),'left',True),(-2002,300))
        self.assertEqual(dock_position(bounds,(100,130),(-1000,300),'right',True),(-18,300))
        self.assertEqual(dock_position(bounds,(100,130),(-1000,300),'top',True),(-1000,-112))
        self.assertEqual(dock_position(bounds,(100,130),(-1000,300),'bottom',True),(-1000,1062))
        self.assertEqual(dock_position(bounds,(100,130),(2000,2000),None),(-100,950))


if __name__=='__main__':unittest.main()
