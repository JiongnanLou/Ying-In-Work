"""Explicit opt-in hardware check. No frame is saved or sent outside localhost."""
import json
import time
import urllib.request
from pathlib import Path

runtime=Path('tmp/packaged-hardware-qa/runtime.json')
deadline=time.monotonic()+30
while not runtime.exists() and time.monotonic()<deadline:time.sleep(.25)
cfg=json.loads(runtime.read_text())
def req(path,data=None):
    r=urllib.request.Request(cfg['url']+'/api/'+path,
        data=json.dumps(data).encode() if data is not None else None,
        headers={'Content-Type':'application/json','X-InWork-Token':cfg['token']})
    with urllib.request.urlopen(r,timeout=35) as response:return json.load(response)

report={'build':'standalone-exe'}
try:
    report['devices']=req('devices')
    report['camera']=req('camera/start',{})
    report['voice_start']=req('voice/start',{})
    time.sleep(3)
    report['voice_ready']=req('status')['voice']['active']
    req('voice/stop',{})
    req('exercise/start',{'kind':'neck','hardware':True})
    deadline=time.monotonic()+110
    while time.monotonic()<deadline:
        status=req('status')
        if not status['exercise'].get('active'):
            report['neck_exercise']=status['exercise']
            break
        time.sleep(.5)
    else:
        req('exercise/stop',{})
        report['neck_exercise']={'error':'verification timeout'}
    report['after_exercise']=req('status')['camera']
    report['stopped']=req('camera/stop',{})
    report['resumed']=req('camera/start',{})
finally:
    req('camera/stop',{})
    req('voice/stop',{})
    Path('tmp/packaged-hardware-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(report,ensure_ascii=False))
