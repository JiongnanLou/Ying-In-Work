import sys
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from camera_service import NativeCamera
from portrait_tracking import PortraitTracker


class NativeTrackingTests(unittest.TestCase):
    def setUp(self):
        self.faces=[(270,130,100,100)]
        self.calls=[]
        self.mode=0
        self.stream=True
        self.fail_off=False
        camera=SimpleNamespace(running=True,link2=True,generation=1,
            snapshot=lambda:np.zeros((360,640,3),np.uint8))
        camera.status=lambda:{'running':camera.running,'generation':camera.generation,
                              'capabilities':{'tracking':camera.link2}}
        self.service=SimpleNamespace(root=ROOT,camera=camera,settings={'auto_tracking':True},
                    operations=threading.Lock(),native=SimpleNamespace(run=self.sdk))
        self.detector=patch('portrait_tracking.FaceDetector')
        self.detector.start().return_value.detect.side_effect=lambda frame:(self.faces,640,360)
        self.tracker=PortraitTracker(self.service)

    def sdk(self,*args):
        self.calls.append(args)
        if args[0]=='tracking':
            if args[1]=='off' and self.fail_off:return {'ok':False,'error':'test device busy'}
            self.mode=int(args[1]=='on')
        return {'ok':True,'mode':self.mode,'pan':0,'tilt':0,'stream_open':self.stream,'objects':[]}

    def wait_for(self,predicate):
        deadline=time.monotonic()+3
        while time.monotonic()<deadline:
            if predicate():return
            time.sleep(.02)
        self.fail('Tracker did not reach expected state: '+str(self.tracker.status()))

    def tearDown(self):
        self.fail_off=False
        self.tracker.close();self.detector.stop()

    def test_long_absence_keeps_native_mode_without_manual_motion(self):
        self.wait_for(lambda:self.tracker.status()['state']=='centered')
        self.calls.clear()
        self.faces=[]
        self.wait_for(lambda:self.tracker.status()['state']=='waiting')
        # Exceed the removed 1.5-second search threshold.
        time.sleep(1.8)
        self.assertEqual(self.tracker.status()['state'],'waiting')
        self.assertEqual(self.mode,1)
        self.assertTrue(all(c[0]=='telemetry' for c in self.calls),self.calls)
        self.faces=[(270,130,100,100)]
        self.wait_for(lambda:self.tracker.status()['state']=='centered')
        self.assertEqual(self.mode,1)
        self.assertNotIn(('tracking','off'),self.calls)

    def test_resume_with_no_face_still_enables_native_tracking(self):
        self.wait_for(lambda:self.tracker.native_mode)
        self.faces=[]
        with self.service.operations:
            self.tracker.suspend()
            self.assertEqual(self.mode,0)
        self.wait_for(lambda:self.tracker.status()['state']=='waiting')
        self.assertEqual(self.mode,1)
        self.assertTrue(all(c[0] in ('tracking','telemetry') for c in self.calls),self.calls)

    def test_external_mode_change_is_repaired(self):
        self.wait_for(lambda:self.tracker.status()['state']=='centered')
        self.mode=0;self.tracker.last_telemetry=0
        self.wait_for(lambda:self.mode==1)
        self.assertGreaterEqual(self.calls.count(('tracking','on')),2)

    def test_foreground_pause_disables_firmware_and_resume_restores(self):
        self.wait_for(lambda:self.tracker.native_mode)
        with self.service.operations:
            self.tracker.suspend()
            self.assertEqual(self.mode,0)
            time.sleep(.2)
            self.assertEqual(self.mode,0)
        self.wait_for(lambda:self.mode==1)
        self.tracker.pause();self.assertEqual(self.mode,0)
        self.tracker.resume();self.wait_for(lambda:self.mode==1)

    def test_disable_failure_does_not_kill_worker(self):
        self.wait_for(lambda:self.tracker.native_mode)
        self.fail_off=True;self.service.settings['auto_tracking']=False
        self.wait_for(lambda:self.tracker.status()['state']=='error')
        self.assertTrue(self.tracker.thread.is_alive())
        self.fail_off=False
        self.wait_for(lambda:self.tracker.status()['state']=='disabled')

    def test_missing_device_stream_never_reports_success(self):
        self.stream=False
        self.wait_for(lambda:self.tracker.status()['state']=='error')
        self.assertNotIn(('tracking','on'),self.calls)

    def test_console_parser_reads_native_state_and_target(self):
        data=NativeCamera.parse_sdk('Succeed to open camera: Insta360 Link 2\n'
            'mode: 1 status: 0\nstream_open: 1\nplay res: 1280x720@30\n'
            'style: 1\ntrack speed: 1\npan(degree):-4 tilt(degree):12\n'
            'x:0.2 y:0.1 w:0.3 h:0.4\n')
        self.assertTrue(data['ok']);self.assertTrue(data['stream_open'])
        self.assertEqual(data['mode'],1);self.assertEqual(data['objects'],[[.2,.1,.3,.4]])
        self.assertFalse(NativeCamera.parse_sdk('Succeed to open camera: Insta360 Link 2C')['ok'])


if __name__=='__main__':unittest.main()
