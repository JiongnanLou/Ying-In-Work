import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from service import ProductService
from server import create_app
from camera_service import is_link2
from eyelei.tracker import EyeFatigueTracker
from jiuzuo.tracker import SedentaryTracker
from backend.ai.config_store import AIConfigStore
from backend.ai.vision import VisionAnalyzer, AnalysisError


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.svc=ProductService(ROOT,Path(self.tmp.name))
        self.app=create_app(self.svc,'test-token')
        self.client=self.app.test_client()
        self.headers={'X-InWork-Token':'test-token'}

    def tearDown(self):
        self.svc.close()
        self.svc.thread.join(timeout=2)
        self.tmp.cleanup()

    def post(self,path,data={}):
        return self.client.post('/api/'+path,json=data,headers=self.headers)

    def test_mutations_require_token_and_same_origin(self):
        self.assertEqual(self.client.post('/api/focus/start',json={}).status_code,403)
        headers={**self.headers,'Origin':'https://example.com'}
        self.assertEqual(self.client.post('/api/focus/start',json={},headers=headers).status_code,403)
        self.assertEqual(self.client.get('/api/status').status_code,403)

    def test_focus_without_camera_persists(self):
        self.assertEqual(self.post('focus/start',{'minutes':1}).status_code,200)
        self.assertFalse(self.svc.camera.running)
        self.post('focus/stop')
        self.assertEqual(self.svc.history()['work_sessions'][0]['status'],'completed')

    def test_focus_completes_and_records_once(self):
        self.svc.focus_start(1)
        self.svc.focus['deadline']=time.monotonic()-.1
        time.sleep(.65)
        self.assertFalse(self.svc.focus['active'])
        self.assertEqual(len([e for e in self.svc.history()['events'] if e['kind']=='focus']),1)

    def test_no_unconfigured_or_unconsented_cloud_call(self):
        with patch.object(self.svc.ai,'analyze') as mock:
            self.assertEqual(self.post('analyze',{'kind':'dark_circle'}).status_code,400)
            self.post('settings',{'cloud_consent':True})
            self.assertEqual(self.post('analyze',{'kind':'dark_circle'}).status_code,400)
            self.assertFalse(mock.called)
        self.assertEqual(self.svc.history()['recent'],[])

    def test_pause_does_not_wait_for_cloud_request(self):
        self.svc.operations.acquire()
        try:
            started=time.monotonic()
            self.svc.stop_camera()
            self.assertLess(time.monotonic()-started,1)
            self.assertTrue(self.svc.job_cancel.is_set())
        finally:self.svc.operations.release()

    def test_preferences_validation_and_persistence(self):
        response=self.post('settings',{'sit_minutes':20,'eye_minutes':15,'dnd':True})
        self.assertEqual(response.status_code,200)
        saved=json.loads(self.svc.settings_path.read_text())
        self.assertEqual(saved['sit_minutes'],20)
        self.assertEqual(self.post('settings',{'sit_minutes':0}).status_code,400)
        self.assertEqual(self.post('settings',{'cloud_consent':'true'}).status_code,400)

    def test_data_clear_preserves_preferences_and_has_guard(self):
        self.svc.event('game','one')
        self.assertEqual(self.post('data/clear').status_code,400)
        self.assertEqual(self.post('data/clear',{'confirm':True}).status_code,200)
        self.assertEqual(self.svc.history()['events'],[])

    def test_exercise_cancellation_releases_operation(self):
        self.svc.start_exercise('neck', hardware=False)
        time.sleep(.05)
        self.svc.exercise_cancel.set()
        self.svc.exercise_thread.join(timeout=3)
        self.assertFalse(self.svc.exercise['active'])
        self.assertFalse(self.svc.exercise['completed'])
        self.assertTrue(self.svc.operations.acquire(blocking=False))
        self.svc.operations.release()

    def test_calories_are_not_enabled(self):
        self.assertEqual(self.post('analyze',{'kind':'food'}).status_code,400)

    def test_secrets_never_in_status(self):
        self.svc.ai.api_key='test-not-a-real-secret'
        self.assertNotIn(self.svc.ai.api_key,json.dumps(self.svc.status()))


class ModuleTests(unittest.TestCase):
    def test_only_exact_link2(self):
        self.assertTrue(is_link2('Insta360 Link 2'))
        self.assertFalse(is_link2('Integrated Camera'))
        self.assertFalse(is_link2('Insta360 Link 2C'))

    def test_sedentary_reset_after_absence(self):
        t=SedentaryTracker(3)
        self.assertFalse(t.update(True,0))
        self.assertTrue(t.update(True,3))
        self.assertFalse(t.update(True,4))
        t.update(False,5)
        self.assertTrue(t.update(True,8))

    def test_eye_requires_consecutive_presence(self):
        t=EyeFatigueTracker(2,2)
        t.update(True,0);t.update(True,2)
        self.assertTrue(t.update(True,4))
        t.reset();t.update(True,10);t.update(True,12);t.update(False,14)
        self.assertEqual(t.consecutive_cycles,0)

    def test_dpapi_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            store=AIConfigStore(Path(d)/'ai.json')
            store.save('unit-test-key','https://example.com/v1','test-model')
            self.assertNotIn('unit-test-key',store.path.read_text())
            self.assertEqual(store.load()['api_key'],'unit-test-key')

    def test_invalid_model_numbers_rejected(self):
        data={'summary':'x','score':float('nan'),'confidence':.7,'activity':'unknown','metrics':{},'suggestions':[]}
        with self.assertRaises(AnalysisError):VisionAnalyzer._validate_result(data)


if __name__=='__main__':unittest.main()
