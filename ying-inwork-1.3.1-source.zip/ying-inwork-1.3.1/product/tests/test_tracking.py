import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from camera_service import CameraService
from service import ProductService
from server import create_app


class CameraTests(unittest.TestCase):
    def test_inventory_prefers_exact_link2_but_supports_builtin(self):
        inventory=[SimpleNamespace(index=0,name='Integrated Camera'),
                   SimpleNamespace(index=1,name='Insta360 Link 2C'),
                   SimpleNamespace(index=2,name='Insta360 Link 2')]
        with patch('camera_service.enumerate_cameras',return_value=inventory):
            c=CameraService()
            self.assertEqual([d['index'] for d in c.candidates()],[2,0,1])
            self.assertTrue(all(d['supported'] for d in c.devices()))
            self.assertFalse(c.devices()[1]['link2'])

    def test_absent_or_failed_link_uses_local_stream(self):
        for link_present in (False,True):
            c=CameraService()
            ds=[{'index':0,'name':'Integrated Camera','link2':False}]
            if link_present:ds.append({'index':1,'name':'Insta360 Link 2','link2':True})
            class Capture:
                def __init__(self,index,*_):self.open=index==0
                def set(self,*_):pass
                def isOpened(self):return self.open
                def read(self):return True,np.zeros((120,160,3),np.uint8)
                def release(self):pass
            with patch.object(c,'devices',return_value=ds),patch.object(c,'open_capture',side_effect=lambda device:Capture(device['index'])):
                try:
                    s=c.start()
                    self.assertTrue(s['running'])
                    self.assertEqual(s['device'],'Integrated Camera')
                    self.assertFalse(any(s['capabilities'].values()))
                    self.assertEqual(c.snapshot().shape,(120,160,3))
                finally:c.stop()

    def test_no_camera_returns_actionable_error(self):
        c=CameraService()
        with patch.object(c,'devices',return_value=[]):
            with self.assertRaisesRegex(ValueError,'未发现可用摄像头'):c.start()

    def test_link_stream_loss_falls_back_and_increments_generation(self):
        c=CameraService()
        devices=[{'index':1,'name':'Insta360 Link 2','link2':True},
                 {'index':0,'name':'Integrated Camera','link2':False}]
        class Capture:
            def __init__(self,index,*_):self.index=index;self.count=0
            def set(self,*_):pass
            def isOpened(self):return True
            def read(self):
                self.count+=1
                if self.index==1 and self.count>5:return False,None
                return True,np.zeros((120,160,3),np.uint8)
            def release(self):pass
        with patch.object(c,'devices',return_value=devices),patch.object(c,'open_capture',side_effect=lambda device:Capture(device['index'])):
            try:
                self.assertTrue(c.start()['link2'])
                deadline=time.monotonic()+4
                while c.generation<2 and time.monotonic()<deadline:time.sleep(.05)
                self.assertEqual(c.generation,2)
                self.assertTrue(c.running)
                self.assertFalse(c.status()['capabilities']['gimbal'])
            finally:c.stop()


class HardwareGuardTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.s=ProductService(ROOT,Path(self.tmp.name))

    def tearDown(self):
        self.s.close();self.s.thread.join(2);self.tmp.cleanup()

    def test_local_camera_never_calls_sdk_even_direct_api(self):
        self.s.camera.running=True
        self.s.camera.link2=False
        with patch.object(self.s.native,'run') as sdk:
            time.sleep(.85)
            self.assertEqual(self.s.tracking.status()['state'],'unsupported')
            client=create_app(self.s,'test').test_client()
            for path,data in [('camera/center',{}),('exercise/start',{'kind':'neck','hardware':True})]:
                r=client.post('/api/'+path,json=data,headers={'X-InWork-Token':'test'})
                self.assertEqual(r.status_code,400)
            self.s.start_exercise('neck')
            self.assertFalse(self.s.exercise['hardware'])
            self.s.exercise_cancel.set();self.s.exercise_thread.join(2)
            sdk.assert_not_called()

    def test_tracking_optout_preserves_existing_preferences(self):
        self.s.update_settings({'auto_tracking':False,'auto_start':False,'floating_window':False})
        self.s.camera.running=True;self.s.camera.link2=True
        with patch.object(self.s.native,'run') as sdk:
            time.sleep(.8)
            sdk.assert_not_called()
            self.assertEqual(self.s.tracking.status()['state'],'disabled')
        saved=json.loads(self.s.settings_path.read_text())
        self.assertFalse(saved['auto_tracking'])
        self.assertFalse(saved['auto_start'])
        self.assertFalse(saved['floating_window'])

    def test_foreground_activity_prevents_tracking_motion(self):
        self.s.camera.running=True;self.s.camera.link2=True
        with patch.object(self.s.native,'run') as sdk:
            self.s.operations.acquire()
            try:
                time.sleep(.8)
                sdk.assert_not_called()
                self.assertEqual(self.s.tracking.status()['state'],'activity')
            finally:
                self.s.camera.running=False
                self.s.operations.release()


if __name__=='__main__':unittest.main()
